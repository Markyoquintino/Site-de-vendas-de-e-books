# DigitalQuintino — projeto completo

Pacote independente da página DigitalQuintino, com código-fonte e capas locais. As referências `/manus-storage/...` foram convertidas para `/assets/...` para que o projeto funcione fora do WebDev.

## Requisitos

- Node.js 18+
- pnpm 9+

## Executar localmente

```bash
pnpm install
pnpm dev
```

Abra o endereço exibido pelo Vite.

## Gerar build

```bash
pnpm check
pnpm build
```

O pacote inclui as páginas `/` e `/admin`, os componentes, estilos, configurações e as 18 imagens utilizadas no catálogo e no hero. `node_modules`, `.git`, logs internos e artefatos temporários foram omitidos para manter o download leve e reproduzível.
